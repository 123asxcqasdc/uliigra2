#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import hashlib
import os
import random
import string
from datetime import datetime
import struct
import zlib
import base64
import sys

# Фикс для Windows
if sys.platform == 'win32':
    try:
        import ctypes
        kernel32 = ctypes.windll.kernel32
        kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
    except:
        pass

try:
    import tkinter as tk
    from tkinter import ttk, messagebox, filedialog, simpledialog
except ImportError:
    print("❌ Ошибка: Tkinter не установлен. Установите python3-tk")
    sys.exit(1)

# ============ ФОРМАТ .ULIPASSES ============
class UliPassFormat:
    MAGIC = b'ULIP'
    VERSION = 3
    
    @staticmethod
    def _encode_data(keys_data):
        json_str = json.dumps(keys_data, ensure_ascii=False, separators=(',', ':'))
        json_bytes = json_str.encode('utf-8')
        key = b'ULIPASS2024'
        encrypted = bytearray(json_bytes)
        for i in range(len(encrypted)):
            encrypted[i] = encrypted[i] ^ key[i % len(key)]
        return base64.b64encode(encrypted)
    
    @staticmethod
    def _decode_data(encoded_data):
        encrypted = base64.b64decode(encoded_data)
        key = b'ULIPASS2024'
        decrypted = bytearray(encrypted)
        for i in range(len(decrypted)):
            decrypted[i] = decrypted[i] ^ key[i % len(key)]
        return json.loads(decrypted.decode('utf-8'))
    
    @staticmethod
    def save_to_file(filename, keys_data):
        encoded_data = UliPassFormat._encode_data(keys_data)
        with open(filename, 'wb') as f:
            f.write(UliPassFormat.MAGIC)
            f.write(struct.pack('B', UliPassFormat.VERSION))
            f.write(struct.pack('I', len(encoded_data)))
            crc = zlib.crc32(encoded_data) & 0xFFFFFFFF
            f.write(struct.pack('I', crc))
            f.write(encoded_data)
    
    @staticmethod
    def load_from_file(filename):
        if not os.path.exists(filename):
            raise FileNotFoundError(f"Файл {filename} не найден")
        with open(filename, 'rb') as f:
            magic = f.read(4)
            if magic != UliPassFormat.MAGIC:
                raise ValueError("Неверный формат")
            version = struct.unpack('B', f.read(1))[0]
            if version != UliPassFormat.VERSION:
                raise ValueError(f"Неподдерживаемая версия {version}")
            data_len = struct.unpack('I', f.read(4))[0]
            crc_stored = struct.unpack('I', f.read(4))[0]
            encoded_data = f.read(data_len)
            crc_calc = zlib.crc32(encoded_data) & 0xFFFFFFFF
            if crc_calc != crc_stored:
                raise ValueError("CRC проверка не пройдена")
            return UliPassFormat._decode_data(encoded_data)

# ============ МЕНЕДЖЕР КЛЮЧЕЙ ============
class KeyManager:
    def __init__(self, keys_file=None):
        if keys_file is None:
            keys_file = "ulipass_keys.ulipasses"
        self.keys_file = os.path.abspath(keys_file)
        self.keys = {"keys": [], "aliases": {}}
        self.load_keys()
    
    def load_keys(self):
        if os.path.exists(self.keys_file):
            try:
                data = UliPassFormat.load_from_file(self.keys_file)
                if isinstance(data, list):
                    self.keys = {"keys": data, "aliases": {k['alias']: k['hash'] for k in data}}
                else:
                    self.keys = data
                return True
            except Exception:
                self.keys = {"keys": [], "aliases": {}}
                return False
        else:
            self.keys = {"keys": [], "aliases": {}}
            return False
    
    def save_keys(self):
        try:
            UliPassFormat.save_to_file(self.keys_file, self.keys['keys'])
            return True
        except Exception:
            return False
    
    def create_key(self, alias=None):
        prefix = "ulipass"
        part1 = ''.join(random.choices(string.ascii_uppercase + string.digits, k=16))
        part2 = ''.join(random.choices(string.ascii_uppercase + string.digits, k=16))
        key = f"{prefix} {part1} {part2}"
        key_hash = hashlib.md5(key.encode('utf-8')).hexdigest()
        
        new_key = {
            "key": key,
            "hash": key_hash,
            "alias": alias or f"Ключ #{len(self.keys['keys']) + 1}",
            "created": datetime.now().isoformat(),
            "last_used": None
        }
        
        self.keys["keys"].append(new_key)
        if alias:
            self.keys["aliases"][alias] = key_hash
        self.save_keys()
        return new_key
    
    def get_key_by_index(self, index):
        if 0 <= index < len(self.keys['keys']):
            return self.keys['keys'][index]
        return None
    
    def delete_key(self, index):
        if 0 <= index < len(self.keys['keys']):
            key_data = self.keys['keys'][index]
            if key_data['alias'] in self.keys['aliases']:
                del self.keys['aliases'][key_data['alias']]
            del self.keys['keys'][index]
            self.save_keys()
            return True
        return False

# ============ СОЗДАТЕЛЬ РАСШИРЕНИЙ ============
class ExtensionCreator:
    def __init__(self, key_manager):
        self.key_manager = key_manager
    
    def create_extension(self, key_hash, output_file=None):
        key_data = None
        for k in self.key_manager.keys['keys']:
            if k['hash'] == key_hash:
                key_data = k
                break
        
        if not key_data:
            return False, "Ключ не найден"
        
        alias = key_data.get('alias', 'key')
        if not output_file:
            output_file = f"extension_{alias.replace(' ', '_')}.js"
        
        template = """(function(Scratch) {
  'use strict';
  if (!Scratch.extensions.unsandboxed) {
    throw new Error("Расширение должно работать в unsandboxed режиме");
  }
  var TARGET_HASH = 'HASH_PLACEHOLDER';
  
  function md5(s) {
    function L(e,t){var n=(e&65535)+(t&65535);return((e>>16)+(t>>16)+(n>>16)<<16)|n&65535}
    function R(e,t){return e<<t|e>>>32-t}
    function C(e,t,n,r,o,i){return L(R(L(L(t,e),L(r,i)),o),n)}
    function D(e,t,n,r,o,i,a){return C(t&n|~t&r,e,t,o,i,a)}
    function E(e,t,n,r,o,i,a){return C(t&r|n&~r,e,t,o,i,a)}
    function F(e,t,n,r,o,i,a){return C(t^n^r,e,t,o,i,a)}
    function G(e,t,n,r,o,i,a){return C(n^(t|~r),e,t,o,i,a)}
    function H(e){var t,n=e.length,r=n+8,o=(r-r%64)/64,i=16*(o+1),a=Array(i-1),u=0,c=0;while(c<n){t=(c-c%4)/4;u=c%4*8;a[t]|=e.charCodeAt(c)<<u;c++}t=(c-c%4)/4;a[t]|=128<<c%4*8;a[i-2]=n<<3;a[i-1]=n>>>29;return a}
    function I(e){var t="",n="",r,o;for(o=0;o<=3;o++){r=e>>>o*8&255;n="0"+r.toString(16);t+=n.substr(n.length-2,2)}return t}
    function J(e){e=e.replace(/\\\\x0d\\\\x0a/g,"\\\\n");for(var t="",n=0;n<e.length;n++){var r=e.charCodeAt(n);if(r<128)t+=String.fromCharCode(r);else if(r>127&&r<2048){t+=String.fromCharCode(r>>6|192);t+=String.fromCharCode(r&63|128)}else{t+=String.fromCharCode(r>>12|224);t+=String.fromCharCode(r>>6&63|128);t+=String.fromCharCode(r&63|128)}}return t}
    var K=Array(),M,N,O,P,Q,R2,S,T,U,V,W,X,Y,Z,$,_,aa,ba,ca,da;s=J(s);K=H(s);M=1732584193;N=4023233417;O=2562383102;P=271733878;for(Q=0;Q<K.length;Q+=16){R2=M;S=N;T=O;U=P;M=D(M,N,O,P,K[Q+0],7,3614090360);P=D(P,M,N,O,K[Q+1],12,3905402710);O=D(O,P,M,N,K[Q+2],17,606105819);N=D(N,O,P,M,K[Q+3],22,3250441966);M=D(M,N,O,P,K[Q+4],7,4118548399);P=D(P,M,N,O,K[Q+5],12,1200080426);O=D(O,P,M,N,K[Q+6],17,2821735955);N=D(N,O,P,M,K[Q+7],22,4249261313);M=D(M,N,O,P,K[Q+8],7,1770035416);P=D(P,M,N,O,K[Q+9],12,2336552879);O=D(O,P,M,N,K[Q+10],17,4294925233);N=D(N,O,P,M,K[Q+11],22,2304563134);M=D(M,N,O,P,K[Q+12],7,1804603682);P=D(P,M,N,O,K[Q+13],12,4254626195);O=D(O,P,M,N,K[Q+14],17,2792965006);N=D(N,O,P,M,K[Q+15],22,1236535329);M=E(M,N,O,P,K[Q+1],5,4129170786);P=E(P,M,N,O,K[Q+6],9,3225465664);O=E(O,P,M,N,K[Q+11],14,643717713);N=E(N,O,P,M,K[Q+0],20,3921069994);M=E(M,N,O,P,K[Q+5],5,3593408605);P=E(P,M,N,O,K[Q+10],9,38016083);O=E(O,P,M,N,K[Q+15],14,3634488961);N=E(N,O,P,M,K[Q+4],20,3889429448);M=E(M,N,O,P,K[Q+9],5,568446438);P=E(P,M,N,O,K[Q+14],9,3275163606);O=E(O,P,M,N,K[Q+3],14,4107603335);N=E(N,O,P,M,K[Q+8],20,1163531501);M=E(M,N,O,P,K[Q+13],5,2850285829);P=E(P,M,N,O,K[Q+2],9,4243563512);O=E(O,P,M,N,K[Q+7],14,1735328473);N=E(N,O,P,M,K[Q+12],20,2368359562);M=F(M,N,O,P,K[Q+5],4,4294588738);P=F(P,M,N,O,K[Q+8],11,2272392833);O=F(O,P,M,N,K[Q+11],16,1839030562);N=F(N,O,P,M,K[Q+14],23,4259657740);M=F(M,N,O,P,K[Q+1],4,2763975236);P=F(P,M,N,O,K[Q+4],11,1272893353);O=F(O,P,M,N,K[Q+7],16,4139469664);N=F(N,O,P,M,K[Q+10],23,3200236656);M=F(M,N,O,P,K[Q+13],4,681279174);P=F(P,M,N,O,K[Q+0],11,3936430074);O=F(O,P,M,N,K[Q+3],16,3572445317);N=F(N,O,P,M,K[Q+6],23,76029189);M=F(M,N,O,P,K[Q+9],4,3654602809);P=F(P,M,N,O,K[Q+12],11,3873151461);O=F(O,P,M,N,K[Q+15],16,530742520);N=F(N,O,P,M,K[Q+2],23,3299628645);M=G(M,N,O,P,K[Q+0],6,4096336452);P=G(P,M,N,O,K[Q+7],10,1126891415);O=G(O,P,M,N,K[Q+14],15,2878612391);N=G(N,O,P,M,K[Q+5],21,4237533241);M=G(M,N,O,P,K[Q+12],6,1700485571);P=G(P,M,N,O,K[Q+3],10,2399980690);O=G(O,P,M,N,K[Q+10],15,4293915773);N=G(N,O,P,M,K[Q+1],21,2240044497);M=G(M,N,O,P,K[Q+8],6,1873313359);P=G(P,M,N,O,K[Q+15],10,4264355552);O=G(O,P,M,N,K[Q+6],15,2734768916);N=G(N,O,P,M,K[Q+13],21,1309151649);M=G(M,N,O,P,K[Q+4],6,4149444226);P=G(P,M,N,O,K[Q+11],10,3174756917);O=G(O,P,M,N,K[Q+2],15,718787259);N=G(N,O,P,M,K[Q+9],21,3951481745);M=L(M,R2);N=L(N,S);O=L(O,T);P=L(P,U)}return I(M)+I(N)+I(O)+I(P)}

  function decodeUliPass(data) {
    try {
      var magic = String.fromCharCode(data[0], data[1], data[2], data[3]);
      if (magic !== 'ULIP') return null;
      var version = data[4];
      if (version !== 3) return null;
      var dataLen = data[5] | (data[6] << 8) | (data[7] << 16) | (data[8] << 24);
      var dataStart = 13;
      var encodedData = data.slice(dataStart, dataStart + dataLen);
      var binaryStr = '';
      for (var i = 0; i < encodedData.length; i++) {
        binaryStr += String.fromCharCode(encodedData[i]);
      }
      var decoded = atob(binaryStr);
      var key = 'ULIPASS2024';
      var decrypted = '';
      for (var i = 0; i < decoded.length; i++) {
        decrypted += String.fromCharCode(decoded.charCodeAt(i) ^ key.charCodeAt(i % key.length));
      }
      return JSON.parse(decrypted);
    } catch (e) {
      return null;
    }
  }

  function findKeyInUliPass(data) {
    try {
      var keys = decodeUliPass(data);
      if (!keys || !Array.isArray(keys)) return null;
      for (var i = 0; i < keys.length; i++) {
        var k = keys[i];
        if (k.hash === TARGET_HASH) return k;
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  function isPackaged() {
    return (
      window.location.href.includes('packager') ||
      window.location.href.includes('player') ||
      window.location.href.includes('embed') ||
      window.location.href.includes('packaged') ||
      window.location.href.includes('standalone') ||
      typeof window.__TAURI__ !== 'undefined' ||
      typeof window.electron !== 'undefined' ||
      !document.querySelector('.blocklyWorkspace, .gui, [class*="editor"]')
    );
  }

  class PasswordProtection {
    constructor() {
      this.isUnlocked = false;
      this.lockScreen = null;
      this.isInitialized = false;
      this.isPackaged = isPackaged();
      
      if (this.isPackaged) {
        this.isUnlocked = true;
        return;
      }
      
      this.keychainPaths = [];
      this.loadKeychainPaths();
      this.checkSavedKeychains();
      
      if (!this.isUnlocked) {
        this.initializeLockScreen();
      }
    }

    loadKeychainPaths() {
      try {
        var saved = localStorage.getItem('ulipass_keychains');
        if (saved) {
          this.keychainPaths = JSON.parse(saved);
        }
      } catch (e) {}
    }

    saveKeychainPaths() {
      try {
        localStorage.setItem('ulipass_keychains', JSON.stringify(this.keychainPaths));
      } catch (e) {}
    }

    addKeychainPath(path) {
      if (!this.keychainPaths.includes(path)) {
        this.keychainPaths.push(path);
        this.saveKeychainPaths();
      }
    }

    async checkSavedKeychains() {
      for (var i = 0; i < this.keychainPaths.length; i++) {
        var path = this.keychainPaths[i];
        try {
          var response = await fetch(path);
          if (response.ok) {
            var buffer = await response.arrayBuffer();
            var data = new Uint8Array(buffer);
            var keyData = findKeyInUliPass(data);
            if (keyData) {
              this.isUnlocked = true;
              this.unlockProject();
              return;
            }
          }
        } catch (e) {
          this.keychainPaths = this.keychainPaths.filter(function(p) { return p !== path; });
          this.saveKeychainPaths();
        }
      }
    }

    unlockProject() {
      if (this.lockScreen) {
        this.lockScreen.style.opacity = '0';
        var self = this;
        setTimeout(function() {
          if (self && self.lockScreen) {
            self.lockScreen.style.display = 'none';
          }
        }, 300);
      }
    }

    initializeLockScreen() {
      if (this.isInitialized) return;
      
      this.lockScreen = document.createElement('div');
      this.lockScreen.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.85);display:flex;justify-content:center;align-items:center;z-index:999999;transition:opacity 0.3s;';

      this.lockScreen.innerHTML = '<div style="background:rgba(255,255,255,0.05);backdrop-filter:blur(20px);padding:40px;border-radius:20px;text-align:center;border:1px solid rgba(255,255,255,0.1);max-width:400px;width:90%;">' +
        '<div style="width:80px;height:80px;margin:0 auto 20px;background:rgba(255,255,255,0.1);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:40px;">🔒</div>' +
        '<div id="drop-zone" style="border:2px dashed rgba(255,255,255,0.2);border-radius:12px;padding:30px 20px;margin:20px 0;cursor:pointer;transition:all 0.3s;">' +
        '<div style="color:rgba(255,255,255,0.5);font-size:14px;">📁</div></div>' +
        '<input type="file" id="file-input" accept=".ulipasses" style="display:none;">' +
        '<div id="file-status" style="color:rgba(255,255,255,0.6);font-size:12px;min-height:20px;margin-top:10px;"></div>' +
        '<div id="error-msg" style="color:#ff6b6b;font-size:12px;margin-top:10px;display:none;">Ключ не найден</div>' +
        '<div id="success-msg" style="color:#69db7c;font-size:12px;margin-top:10px;display:none;">✅ Ключ найден</div></div>';

      document.body.appendChild(this.lockScreen);

      var dropZone = document.getElementById('drop-zone');
      var fileInput = document.getElementById('file-input');
      var errorMsg = document.getElementById('error-msg');
      var successMsg = document.getElementById('success-msg');
      var fileStatus = document.getElementById('file-status');

      var self = this;

      dropZone.addEventListener('click', function() {
        fileInput.click();
      });

      fileInput.addEventListener('change', function(e) {
        var file = e.target.files[0];
        if (file) {
          self.handleFile(file, dropZone, fileStatus, errorMsg, successMsg);
        }
      });

      dropZone.addEventListener('dragover', function(e) {
        e.preventDefault();
        dropZone.style.borderColor = 'rgba(76,175,80,0.5)';
        dropZone.style.background = 'rgba(255,255,255,0.05)';
      });

      dropZone.addEventListener('dragleave', function(e) {
        e.preventDefault();
        dropZone.style.borderColor = 'rgba(255,255,255,0.2)';
        dropZone.style.background = 'transparent';
      });

      dropZone.addEventListener('drop', function(e) {
        e.preventDefault();
        dropZone.style.borderColor = 'rgba(255,255,255,0.2)';
        dropZone.style.background = 'transparent';
        
        var file = e.dataTransfer.files[0];
        if (file) {
          self.handleFile(file, dropZone, fileStatus, errorMsg, successMsg);
        }
      });

      this.isInitialized = true;
    }

    handleFile(file, dropZone, fileStatus, errorMsg, successMsg) {
      var reader = new FileReader();
      var self = this;
      
      reader.onload = function(e) {
        try {
          var data = new Uint8Array(e.target.result);
          var keyData = findKeyInUliPass(data);
          
          if (keyData) {
            self.addKeychainPath(file.name);
            
            dropZone.style.borderColor = 'rgba(76,175,80,0.5)';
            dropZone.style.background = 'rgba(76,175,80,0.1)';
            fileStatus.textContent = '✅ ' + keyData.alias;
            fileStatus.style.color = '#69db7c';
            errorMsg.style.display = 'none';
            successMsg.style.display = 'block';
            
            self.isUnlocked = true;
            setTimeout(function() {
              self.unlockProject();
            }, 500);
          } else {
            dropZone.style.borderColor = 'rgba(255,107,107,0.5)';
            dropZone.style.background = 'rgba(255,107,107,0.1)';
            fileStatus.textContent = 'Ключ не найден';
            fileStatus.style.color = '#ff6b6b';
            errorMsg.style.display = 'block';
            successMsg.style.display = 'none';
          }
        } catch (err) {
          dropZone.style.borderColor = 'rgba(255,107,107,0.5)';
          dropZone.style.background = 'rgba(255,107,107,0.1)';
          fileStatus.textContent = 'Ошибка';
          fileStatus.style.color = '#ff6b6b';
          errorMsg.style.display = 'block';
          successMsg.style.display = 'none';
        }
      };
      reader.readAsArrayBuffer(file);
    }

    isUnlockedStatus() {
      return this.isUnlocked;
    }
  }

  var passwordProtection = new PasswordProtection();

  class PasswordExtension {
    getInfo() {
      return {
        id: 'passwordprotection',
        name: '🔑 UliPass',
        color1: '#FF8C00',
        color2: '#FF6B00',
        blocks: [
          {
            opcode: 'isUnlocked',
            blockType: Scratch.BlockType.BOOLEAN,
            text: 'проект разблокирован?'
          }
        ]
      };
    }

    isUnlocked() {
      return passwordProtection.isUnlockedStatus();
    }
  }

  Scratch.extensions.register(new PasswordExtension());
})(window.Scratch);"""
        
        code = template.replace('HASH_PLACEHOLDER', key_data['hash'])
        code = code.replace('ALIAS_PLACEHOLDER', alias)
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(code)
        
        return True, output_file

# ============ ГРАФИЧЕСКИЙ ИНТЕРФЕЙС ============
class TotalCommanderUI:
    def __init__(self, root):
        self.root = root
        self.root.title("🔑 UliPass Manager")
        self.root.geometry("1200x700")
        self.root.configure(bg='#2b2b2b')
        
        self.style = ttk.Style()
        self.style.theme_use('clam')
        self.style.configure('Title.TLabel', background='#2b2b2b', foreground='white', font=('Segoe UI', 12, 'bold'))
        self.style.configure('Panel.TFrame', background='#3c3c3c')
        
        self.km = KeyManager()
        self.ec = ExtensionCreator(self.km)
        self.current_file = self.km.keys_file
        
        self.create_widgets()
        self.load_keys()
        self.update_status()
    
    def create_widgets(self):
        # Меню
        menubar = tk.Menu(self.root, bg='#2b2b2b', fg='white')
        self.root.config(menu=menubar)
        
        file_menu = tk.Menu(menubar, tearoff=0, bg='#2b2b2b', fg='white')
        menubar.add_cascade(label="📁 Файл", menu=file_menu)
        file_menu.add_command(label="Открыть ключницу", command=self.open_ulipasses_file)
        file_menu.add_command(label="Создать новую ключницу", command=self.create_new_keys_file)
        file_menu.add_separator()
        file_menu.add_command(label="Импортировать ключи", command=self.import_keys)
        file_menu.add_separator()
        file_menu.add_command(label="Выйти", command=self.root.quit)
        
        keys_menu = tk.Menu(menubar, tearoff=0, bg='#2b2b2b', fg='white')
        menubar.add_cascade(label="🔑 Ключи", menu=keys_menu)
        keys_menu.add_command(label="Создать ключ", command=self.create_key_dialog)
        keys_menu.add_command(label="Удалить ключ", command=self.delete_key)
        
        ext_menu = tk.Menu(menubar, tearoff=0, bg='#2b2b2b', fg='white')
        menubar.add_cascade(label="📦 Расширения", menu=ext_menu)
        ext_menu.add_command(label="Создать расширение", command=self.create_extension)
        ext_menu.add_command(label="Создать все расширения", command=self.create_all_extensions)
        
        help_menu = tk.Menu(menubar, tearoff=0, bg='#2b2b2b', fg='white')
        menubar.add_cascade(label="❓ Справка", menu=help_menu)
        help_menu.add_command(label="О программе", command=self.show_about)
        
        # Панель инструментов
        toolbar = tk.Frame(self.root, bg='#2b2b2b', height=40)
        toolbar.pack(fill=tk.X, padx=5, pady=5)
        
        tk.Label(toolbar, text="🔑 UliPass Manager", font=('Segoe UI', 14, 'bold'), 
                bg='#2b2b2b', fg='white').pack(side=tk.LEFT, padx=10)
        
        tk.Button(toolbar, text="📂 Открыть ключницу", command=self.open_ulipasses_file,
                 bg='#3c3c3c', fg='white', relief=tk.FLAT).pack(side=tk.LEFT, padx=2)
        tk.Button(toolbar, text="➕ Создать ключ", command=self.create_key_dialog,
                 bg='#3c3c3c', fg='white', relief=tk.FLAT).pack(side=tk.LEFT, padx=2)
        tk.Button(toolbar, text="📦 Создать расширение", command=self.create_extension,
                 bg='#3c3c3c', fg='white', relief=tk.FLAT).pack(side=tk.LEFT, padx=2)
        
        self.status_label = tk.Label(toolbar, text="Готов", font=('Segoe UI', 10),
                                     bg='#2b2b2b', fg='#888888')
        self.status_label.pack(side=tk.RIGHT, padx=10)
        
        # Основная панель
        main_frame = tk.Frame(self.root, bg='#2b2b2b')
        main_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Левая панель - список ключей
        left_frame = tk.Frame(main_frame, bg='#3c3c3c', relief=tk.SUNKEN, bd=2)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=2)
        
        tk.Label(left_frame, text="📁 СОХРАНЕННЫЕ КЛЮЧИ", font=('Segoe UI', 11, 'bold'),
                bg='#3c3c3c', fg='white').pack(pady=5)
        
        tk.Label(left_frame, text=f"Файл: {os.path.basename(self.current_file)}", font=('Segoe UI', 9),
                bg='#3c3c3c', fg='#888888').pack()
        
        list_frame = tk.Frame(left_frame, bg='#3c3c3c')
        list_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.keys_listbox = tk.Listbox(list_frame, bg='#2b2b2b', fg='white', 
                                       selectbackground='#0078d7', selectforeground='white',
                                       font=('Consolas', 11), height=20)
        scroll = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.keys_listbox.yview)
        self.keys_listbox.configure(yscrollcommand=scroll.set)
        
        self.keys_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Правая панель - информация о ключе
        right_frame = tk.Frame(main_frame, bg='#3c3c3c', relief=tk.SUNKEN, bd=2)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=2)
        
        tk.Label(right_frame, text="📋 ИНФОРМАЦИЯ О КЛЮЧЕ", font=('Segoe UI', 11, 'bold'),
                bg='#3c3c3c', fg='white').pack(pady=5)
        
        self.info_text = tk.Text(right_frame, bg='#2b2b2b', fg='#00ff00', 
                                 font=('Consolas', 10), wrap=tk.WORD, height=25)
        info_scroll = tk.Scrollbar(right_frame, orient=tk.VERTICAL, command=self.info_text.yview)
        self.info_text.configure(yscrollcommand=info_scroll.set)
        
        self.info_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        info_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Кнопки действий - ТОЛЬКО УДАЛЕНИЕ (создание расширения только на панели инструментов)
        actions_frame = tk.Frame(right_frame, bg='#3c3c3c')
        actions_frame.pack(fill=tk.X, pady=5)
        
        tk.Button(actions_frame, text="🗑 Удалить ключ", command=self.delete_key,
                 bg='#f44336', fg='white', relief=tk.FLAT, padx=20).pack(side=tk.LEFT, padx=5)
        
        self.keys_listbox.bind('<<ListboxSelect>>', self.on_key_select)
    
    def load_keys(self):
        self.keys_listbox.delete(0, tk.END)
        self.km = KeyManager(self.current_file)
        
        for key_data in self.km.keys['keys']:
            display = f"🔑 {key_data['alias']}"
            self.keys_listbox.insert(tk.END, display)
        
        if self.keys_listbox.size() > 0:
            self.keys_listbox.selection_set(0)
            self.on_key_select(None)
        
        self.update_status(f"Загружено {len(self.km.keys['keys'])} ключей")
    
    def update_status(self, text="Готов", color='#888888'):
        self.status_label.config(text=text, fg=color)
        self.root.update()
    
    def on_key_select(self, event):
        selection = self.keys_listbox.curselection()
        if selection:
            idx = selection[0]
            if 0 <= idx < len(self.km.keys['keys']):
                key_data = self.km.keys['keys'][idx]
                self.info_text.delete(1.0, tk.END)
                self.info_text.insert(tk.END, f"📌 ПСЕВДОНИМ:\n{key_data['alias']}\n\n")
                self.info_text.insert(tk.END, f"📅 СОЗДАН:\n{key_data['created']}\n\n")
                if key_data.get('last_used'):
                    self.info_text.insert(tk.END, f"🕐 ПОСЛЕДНИЙ ВХОД:\n{key_data['last_used']}\n")
                self.info_text.insert(tk.END, f"\n🔐 Хеш:\n{key_data['hash']}\n\n")
                self.info_text.insert(tk.END, f"✅ ВЫБРАН ДЛЯ СОЗДАНИЯ РАСШИРЕНИЯ")
    
    def create_key_dialog(self):
        alias = simpledialog.askstring("Создать ключ", 
                                       "Введите псевдоним для ключа:",
                                       parent=self.root)
        if alias and alias.strip():
            key_data = self.km.create_key(alias.strip())
            self.load_keys()
            self.update_status(f"✅ Ключ '{alias}' создан", '#4CAF50')
            
            messagebox.showinfo("Ключ создан", 
                               f"✅ Ключ создан!\n\n"
                               f"📌 Псевдоним: {key_data['alias']}\n"
                               f"🔐 Хеш: {key_data['hash']}")
    
    def open_ulipasses_file(self):
        file = filedialog.askopenfilename(
            title="Выберите .ulipasses ключницу",
            filetypes=[("UliPass files", "*.ulipasses"), ("All files", "*.*")]
        )
        if file:
            try:
                self.current_file = os.path.abspath(file)
                self.km.keys_file = self.current_file
                self.km.load_keys()
                self.load_keys()
                self.update_status(f"📁 Загружена ключница: {os.path.basename(file)}", '#2196F3')
                
                keys_list = "\n".join([f"• {k['alias']} ({k['hash'][:8]}...)" for k in self.km.keys['keys']])
                messagebox.showinfo("Загрузка", 
                                   f"Загружено {len(self.km.keys['keys'])} ключей:\n\n{keys_list}")
            except Exception as e:
                messagebox.showerror("Ошибка", f"Не удалось загрузить:\n{e}")
    
    def create_new_keys_file(self):
        file = filedialog.asksaveasfilename(
            title="Создать новую ключницу",
            defaultextension=".ulipasses",
            filetypes=[("UliPass files", "*.ulipasses"), ("All files", "*.*")]
        )
        if file:
            self.current_file = os.path.abspath(file)
            self.km = KeyManager(self.current_file)
            self.km.save_keys()
            self.load_keys()
            self.update_status(f"✅ Создана ключница: {os.path.basename(file)}", '#4CAF50')
    
    def import_keys(self):
        file = filedialog.askopenfilename(
            title="Импортировать ключи",
            filetypes=[("UliPass files", "*.ulipasses"), ("All files", "*.*")]
        )
        if file:
            try:
                keys = UliPassFormat.load_from_file(file)
                imported_data = {"keys": keys, "aliases": {k['alias']: k['hash'] for k in keys}}
                
                existing_hashes = {k['hash'] for k in self.km.keys['keys']}
                merged_count = 0
                for key_data in imported_data['keys']:
                    if key_data['hash'] not in existing_hashes:
                        self.km.keys['keys'].append(key_data)
                        if key_data.get('alias'):
                            self.km.keys['aliases'][key_data['alias']] = key_data['hash']
                        merged_count += 1
                
                if merged_count > 0:
                    self.km.save_keys()
                    self.load_keys()
                    self.update_status(f"✅ Импортировано {merged_count} ключей", '#4CAF50')
                else:
                    messagebox.showinfo("Импорт", "Нет новых ключей для импорта")
            except Exception as e:
                messagebox.showerror("Ошибка", f"Не удалось импортировать: {e}")
    
    def delete_key(self):
        selection = self.keys_listbox.curselection()
        if selection:
            idx = selection[0]
            if messagebox.askyesno("Удалить ключ", "Удалить выбранный ключ?"):
                key_data = self.km.keys['keys'][idx]
                self.km.delete_key(idx)
                self.load_keys()
                self.update_status(f"🗑 Ключ '{key_data['alias']}' удален", '#ff9800')
    
    def create_extension(self):
        """Создать расширение для ВЫБРАННОГО ключа"""
        selection = self.keys_listbox.curselection()
        
        if not selection:
            messagebox.showwarning("Внимание", 
                "Сначала выберите ключ в списке (кликните по нему мышкой)")
            return
        
        idx = selection[0]
        
        if idx >= len(self.km.keys['keys']):
            messagebox.showerror("Ошибка", "Ключ не найден")
            return
        
        key_data = self.km.keys['keys'][idx]
        selected_hash = key_data['hash']
        
        default_name = f"extension_{key_data['alias'].replace(' ', '_')}.js"
        output_file = filedialog.asksaveasfilename(
            title=f"Создать расширение для ключа: {key_data['alias']}",
            defaultextension=".js",
            initialfile=default_name,
            filetypes=[("JavaScript files", "*.js"), ("All files", "*.*")]
        )
        
        if output_file:
            success, result = self.ec.create_extension(selected_hash, output_file)
            if success:
                self.update_status(f"✅ Расширение для '{key_data['alias']}' создано", '#4CAF50')
                messagebox.showinfo("Успех", 
                                   f"✅ Расширение создано!\n\n"
                                   f"📌 Ключ: {key_data['alias']}\n"
                                   f"🔐 Хеш: {key_data['hash'][:8]}...\n\n"
                                   f"📁 Сохранено: {os.path.basename(result)}")
            else:
                messagebox.showerror("Ошибка", result)
    
    def create_all_extensions(self):
        if not self.km.keys['keys']:
            messagebox.showwarning("Внимание", "Нет ключей для создания расширений")
            return
        
        folder = filedialog.askdirectory(title="Выберите папку для сохранения")
        if folder:
            count = 0
            for key_data in self.km.keys['keys']:
                output_file = os.path.join(folder, f"extension_{key_data['alias'].replace(' ', '_')}.js")
                success, _ = self.ec.create_extension(key_data['hash'], output_file)
                if success:
                    count += 1
            
            self.update_status(f"✅ Создано {count} расширений", '#4CAF50')
            messagebox.showinfo("Успех", f"✅ Создано {count} расширений в папке:\n{folder}")
    
    def show_about(self):
        messagebox.showinfo("О программе", 
                           "🔑 UliPass Manager v2.0\n\n"
                           "Кросс-платформенный менеджер ключей\n"
                           "Для защиты проектов TurboWarp\n\n"
                           "© УЛИ")

# ============ ЗАПУСК ============
def main():
    try:
        root = tk.Tk()
        app = TotalCommanderUI(root)
        root.mainloop()
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        input("Нажмите Enter для выхода...")

if __name__ == "__main__":
    main()